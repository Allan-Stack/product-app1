import { NumberonlyDirective } from './numberonly.directive';

describe('NumberonlyDirective', () => {
  it('should create an instance', () => {
    const directive = new NumberonlyDirective();
    expect(directive).toBeTruthy();
  });
});
